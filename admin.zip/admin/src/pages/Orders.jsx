import React from 'react'
import { useState } from 'react'
import axios from 'axios';
// import { backendUrl } from 'd:/Gameplay/1HKhtfCExuLfParQmrMxqB/forever-full-stack/admin/src/App';
import { backendUrl, currency } from '../App'
import { useEffect } from 'react';
import { toast } from 'react-toastify'
import { assets } from '../assets/assets';

const Orders = ({ token }) => {
    const [orders, setOrders] = useState([])

    const fetchAllOrders = async () => {
        if (!token) {
            return null;
        }

        try {
            const response = await axios.post(backendUrl + '/api/order/list', {}, { headers: { Authorization: `Bearer ${token}` } })
            console.log(response.data)
            if (response.data.success) {
                setOrders(response.data.orders.reverse())
            } else {
                toast.error(response.data.error)
            }
        } catch (error) {
            toast.error(error.message)
        }
    }

    const statusHandler = async (event, orderId) => {
        try {
            const response = await axios.post(backendUrl + '/api/order/status', { orderId, status: event.target.value }, { headers: { Authorization: `Bearer ${token}` } })
            if (response.data.success) {
                await fetchAllOrders()
            }
        } catch (error) {
            console.log(error)
            toast.error(response.data.message);
        }
    }
    useEffect(() => {
        fetchAllOrders();
    }, [token])
    return (
        <div>
            <h3>Order Page</h3>
            <div>
                {orders.map((order, index) => (
                    <div
                        key={index}
                        className={`grid grid-cols-1 sm:grid-cols-[0.5fr_2fr_1fr] lg:grid-cols-[0.5fr_2fr_1fr_1fr_1fr] 
            gap-3 items-start border-2 p-5 md:p-8 my-3 md:my-4 text-xs sm:text-sm 
            ${order.status === "Cancelled"
                                ? "bg-gray-200 border-gray-300 opacity-70"
                                : "border-gray-200 text-gray-700"
                            }`}
                    >
                        {/* Parcel Icon */}
                        <img className='w-12' src={assets.parcel_icon} alt="parcel-img" />

                        {/* Items & Address */}
                        <div>
                            <div>
                                {order.items.map((item, idx) => (
                                    <p className='py-0.5' key={idx}>
                                        {item.name} x {item.quantity} <span>{item.size}</span>
                                        {idx !== order.items.length - 1 && ","}
                                    </p>
                                ))}
                            </div>
                            <p className='mt-3 mb-2 font-medium'>
                                {order.address.firstName + " " + order.address.lastName}
                            </p>
                            <div>
                                <p>{order.address.street + ","}</p>
                                <p>
                                    {order.address.city + ", " + order.address.state + ", " + order.address.country + ", " + order.address.zipcode}
                                </p>
                            </div>
                            <p>{order.address.phone}</p>

                            {/* ✅ Show Cancel Reason if cancelled */}
                            {order.status === "Cancelled" && order.cancelReason && (
                                <p className="mt-2 text-red-500 font-semibold">
                                    Cancel Reason: <span className="font-normal">{order.cancelReason}</span>
                                </p>
                            )}
                        </div>

                        {/* Payment & Date */}
                        <div>
                            <p className='text-sm sm:text-[15px]'>Items : {order.items.length}</p>
                            <p className='mt-3'>Method : {order.paymentMethod}</p>
                            <p>Payment : {order.payment ? 'Done' : 'Pending'}</p>
                            <p>Date : {new Date(order.date).toLocaleDateString()}</p>
                        </div>

                        {/* Amount */}
                        <p className='text-sm sm:text-[15px]'>
                            {currency}{order.amount}
                        </p>

                        {/* Status Dropdown OR Cancelled Label */}
                        {order.status === "Cancelled" ? (
                            <p className="text-red-500 font-semibold">Cancelled</p>
                        ) : (
                            <select
                                onChange={(event) => statusHandler(event, order._id)}
                                value={order.status}
                                className='p-2 font-semibold'
                            >
                                <option value="Order Placed">Order Placed</option>
                                <option value="Packing">Packing</option>
                                <option value="Shipped">Shipped</option>
                                <option value="Out for delivery">Out for delivery</option>
                                <option value="Delivered">Delivered</option>
                            </select>
                        )}
                    </div>
                ))}

            </div>

        </div>
    )
}

export default Orders